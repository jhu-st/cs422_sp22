package cs422.hw3.part2;

public enum LoanType {
	Auto, Personal, Home, Other;
}
